﻿using CrystalDecisions.ReportAppServer.DataDefModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OnlineAlisverisOtomasyonu
{
    public partial class adminGenel : Form
    {
        public adminGenel()
        {
            InitializeComponent();
        }

        private void adminGenel_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            adminUrunEkrani ekran = new adminUrunEkrani();
            ekran.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            adminMusteri adminMusteri = new adminMusteri();
            adminMusteri.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            personelekle ekle = new personelekle();
            ekle.Show();
        }


        public void backup()
        {
            string connectionString = "Data Source=MEMO\\SQLEXPRESS;Initial Catalog=OnlineAlisveriVT2;User ID=1996;Password=1996;TrustServerCertificate=True";
            string serverName = "MEMO\\SQLEXPRESS";
            string databaseName = "OnlineAlisveriVT2";
            string backupPath = "C:\\Users\\mehme\\Desktop\\backup";
           // string connectionString = $"Data Source={serverName};Initial Catalog={databaseName};Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string backupFileName = $"{backupPath}{databaseName}_{DateTime.Now.ToString("yyyyMMdd_HHmmss")}.bak";
                    string backupQuery = $"BACKUP DATABASE {databaseName} TO DISK = '{backupFileName}' WITH INIT";

                    SqlCommand cmd = new SqlCommand(backupQuery, connection);
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Yedek alma işlemi başarıyla tamamlandı.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Hata oluştu: {ex.Message}");
                }
                finally
                {
                    connection.Close();
                }
            }
        }


       /* public void rebackup()
        {
            string connectionString = "Data Source=MEMO\\SQLEXPRESS;Initial Catalog=OnlineAlisveriVT2;User ID=1996;Password=1996;TrustServerCertificate=True";
            string serverName = "MEMO\\SQLEXPRESS";
            string databaseName = "OnlineAlisveriVT2";
            string backupPath = "C:\\Users\\mehme\\Desktop\\backup";
            string backupFileName = "backupOnlineAlisveriVT2_20231224_144739.bak";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    // Veritabanını geçici olarak kapatma
                    string query = $"ALTER DATABASE {databaseName} SET SINGLE_USER WITH ROLLBACK IMMEDIATE";
                    SqlCommand cmd = new SqlCommand(query, connection);
                    cmd.ExecuteNonQuery();

                    // Yedek dosyasını kullanarak veritabanını geri yükleme
                    query = $"RESTORE DATABASE {databaseName} FROM DISK = '{backupPath}{backupFileName}' WITH REPLACE";
                    cmd = new SqlCommand(query, connection);
                    cmd.ExecuteNonQuery();

                    // Veritabanını tekrar çoklu kullanıcıya açma
                    query = $"ALTER DATABASE {databaseName} SET MULTI_USER";
                    cmd = new SqlCommand(query, connection);
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Veritabanı geri yükleme işlemi başarıyla tamamlandı.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Hata oluştu: {ex.Message}");
                }
                finally
                {
                    connection.Close();
                }
            }
       
        }
       */
        private void button4_Click(object sender, EventArgs e)
        {
            backup();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            
        }
    }
}
